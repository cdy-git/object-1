import os from 'os'

const platform = os.platform()

export {
  platform
}
