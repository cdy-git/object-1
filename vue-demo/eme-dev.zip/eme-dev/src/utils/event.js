import EventEmitter from 'events'

const event = new EventEmitter()

export default event
