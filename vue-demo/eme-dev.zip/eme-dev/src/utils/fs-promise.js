import fs from 'fs'
import pify from 'pify'

export default pify(fs)
