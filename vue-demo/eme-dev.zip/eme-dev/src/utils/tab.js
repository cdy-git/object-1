
let id = 0

export const tabId = {
  create() {
    return id++
  }
}
