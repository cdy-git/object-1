'use strict'

const _ = module.exports = {}

_.$ = document.querySelector.bind(document)

_.$$ = document.querySelectorAll.bind(document)
