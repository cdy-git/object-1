## Hola!

The best time to learn Markdown is 10 years ago, the second is __now__!

EME is trying to give you the best experience of writing in Markdown.

Markdown shines ✨

![shiny](http://ww4.sinaimg.cn/large/a15b4afegw1f6499jo5ruj20iw0anmxv.jpg)

## Focus Mode

The first feature that most markdown editors do not have is, focus the paragraph you are actually writing. It reduces a lot of distractions when you are working on a long post. Use <kbd>Ctrl/CMD + \</kbd> to toggle it.

## Distraction Free Mode

One step further, you may want to hide the header and footer when you are writing in full-screen. Use <kbd>Ctrl/CMD + J</kbd> to toggle it.

## Vim Mode

For developers, you may miss the vim key binding, here it is. Use <kbd>Ctrl/CMD + I</kbd> to toggle it.

## Shortcuts

Please view: https://github.com/egoist/eme/wiki/Key-bindings
