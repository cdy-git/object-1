const EventEmitter = require('events')

const event = new EventEmitter()

module.exports = event
