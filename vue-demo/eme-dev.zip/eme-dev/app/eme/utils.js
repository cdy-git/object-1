'use strict'
const _ = module.exports = {}

_.isDev = process.env.NODE_ENV === 'development'
